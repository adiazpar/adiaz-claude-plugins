# Project Knowledge Evaluations

This directory contains tracked, ratified retrieval evaluation cases.
Cases are evidence for benchmarking and profile decisions, not project truth.

Use `benchmark-knowledge` for read-only measurement. `calibrate-knowledge`
writes disposable candidate output under `.re-discipline/cache/calibration/`.
Only `decide-retrieval-profile`, with explicit user approval and passing
gates, may replace the accepted project retrieval profile.

## Ratification

The current ratified corpus contains 64 cases across 14 topics: 32 development
and 32 holdout, with 52 manager cases and 12 drafter cases. Topics and every
judged path (expected, minimum-evidence, citation, and hard-negative) partition
cleanly by split. Exact normalized query text is unique, so repeated wording
cannot silently double-weight one judgment.

What was checked for every case: the query, the expected evidence paths, the
hard negatives, the tier boundary, and the token budget.

How gold labels were established, and the limit of each method:

- **Identifier cases** use terms confirmed by grep to appear in exactly one
  truth-tier document. Term ownership is a mechanical fact, so these labels are
  checkable without judgement.
- **Conceptual cases** assert that a document ANSWERS a question, which term
  counts cannot establish. Each was verified by reading the target's claim at
  its stated line in primary source. Documents whose content was not read carry
  identifier queries only.
- No label was established by a subagent. Drafters investigated failures and
  reported verbatim claims with line numbers; the manager verified each against
  the file before it became a label.

The corpus contains 58 answerable cases and six explicit abstention cases.
Each abstention uses an exact, deliberately absent token and passes only when
the server returns zero eligible results. This tests a satisfiable absence
contract without pretending that a broad ordinary-English query must have no
lexical neighbors.

## Vocabulary-disjoint semantic stratum

The 26 answerable semantic cases added for the expansion declare
`vocabularyPolicy: target-disjoint-v1`. The evaluator analyzes the query and
the full text of every expected document, removes a fixed set of English
function words and query-framing words, retains analyzer terms of four or more
characters, and requires zero shared terms. It also requires at least three
measured query terms so a vacuous question cannot satisfy the rule. The current
receipt is 26 declared, 26 passing, 0 failing.

This is an authoring and benchmark gate, not a claim that lexical overlap is
bad in production queries. It prevents the eval from manufacturing an easy
lane-ablation result by copying a target's vocabulary. Exact identifier cases
and exact absent-token controls are a separate, intentional class and do not
declare this policy.

## Migration scope

This path-based suite is the pre-migration 0.7 passage-retrieval baseline. Ten
campaign-recall cases intentionally target legacy `active/*/CAMPAIGN.md`
master files. The 0.8 migration transforms those master files into structured
campaign, work, run, review, and finding records; these path judgments must not
be relabeled as though the old files survive the cutover.

Run and retain this suite against the release-pinned 0.7 baseline before
physical activation. Post-migration acceptance requires the separate
finding-card evaluation and blinded traversal/host-parity trials over canonical
0.8 handles. The old path suite remains provenance for the before/after receipt,
not the post-migration source of truth.

## Pins

Cases pin `evidencePins` rather than relying only on a corpus-wide fingerprint:
92 pin instances across 65 documents. For a document with an extractable typed
claim, `claimSha256` gates on that claim, its confidence grade, and its
supersession status; unrelated evidence-prose edits remain advisory byte drift.
For active, history, backlog, or other documents without an extractable claim,
the full `contentSha256` is the semantic gate. Their prose is the only available
identity, so a substantive rewrite cannot remain fresh behind the shared
empty-claim digest.

Refresh pins with `pin-evals` after any change to a pinned document. A typed pin
whose non-claim prose changed is refreshed as advisory drift. A changed typed
claim, or any changed document that lacks an extractable claim, is reported and
is not re-stamped without `--force`. Re-answer the affected case before forcing
the new pin; otherwise re-stamping would capture the measurement while making
it look like an independently passing test.
